import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <footer>
        <h5 style={{ margin: 0, textAlign: 'center' }}>
          Copyright &copy; 2013-2018 Georgi Yanev &amp; Sofia Lindberg coded
          with love for little Anton
        </h5>
      </footer>
    )
  }
}
